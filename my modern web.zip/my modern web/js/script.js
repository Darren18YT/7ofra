document.addEventListener('DOMContentLoaded', () => {
    const buttons = document.querySelectorAll('.btn');
    const loader = document.querySelector('.loader');

    function navigateTo(url) {
        loader.style.display = 'flex'; // Show the loader
        setTimeout(() => {
            window.location.href = url; // Redirect after showing loader
        }, 1500); // 1.5 seconds delay
    }

    buttons.forEach(button => {
        button.addEventListener('click', (event) => {
            const href = button.getAttribute('onclick').replace("navigateTo('", "").replace("')", "");
            navigateTo(href);
        });
    });
});
