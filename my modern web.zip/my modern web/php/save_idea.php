<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $idea = $_POST['idea'];
    
    // Path to the file where ideas will be saved
    $file = '../idea.txt';  // Adjust the path if needed

    // Append the idea to 'idea.txt' file
    file_put_contents($file, $idea . "\n", FILE_APPEND | LOCK_EX);
    
    // Display success message and link back to idea.html
    echo "Idea saved successfully! <a href='/idea.html'>Go back</a>";
}
?>
