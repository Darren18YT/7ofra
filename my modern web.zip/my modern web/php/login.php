<?php
// Connecting to the database
$servername = "localhost";
$username = "db"; // Replace with your database username
$password = ""; // Replace with your database password
$dbname = "db;

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Processing the form
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Querying the database for the user
    $sql = "SELECT * FROM users WHERE username='$username'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        // If user found, verify password
        $row = $result->fetch_assoc();
        if (password_verify($password, $row['password'])) {
            // Start session and redirect to index.html
            session_start();
            $_SESSION['username'] = $username;
            header("Location: ../index.html"); // Redirect to your index.html
            exit();
        } else {
            echo "Invalid password!";
        }
    } else {
        echo "User not found!";
    }
}

$conn->close();
?>
